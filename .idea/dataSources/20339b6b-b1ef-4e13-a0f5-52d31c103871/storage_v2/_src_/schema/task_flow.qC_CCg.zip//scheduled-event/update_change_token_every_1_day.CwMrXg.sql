create definer = root@localhost event update_change_token_every_1_day on schedule
    every '1' DAY
        starts '2023-12-28 00:29:52'
    enable
    do
    begin
        update user set number_of_change_tokens = 2 where to_double_token_chane_date IS NULL;
        update user set number_of_change_tokens = 4 where to_double_token_chane_date = now();
    end;

