create definer = root@localhost event update_delete_token_every_month on schedule
    every '1' MONTH
        starts '2023-12-28 00:00:00'
    enable
    do
    BEGIN
        UPDATE user SET has_delete_token = true where 1;
    END;

